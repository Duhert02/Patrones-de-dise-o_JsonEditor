package com.kreitek.pets;

public class BadCommandException extends Exception {
}
