package com.kreitek.editor;


public interface Editor {
    void run(String[] args);

}
