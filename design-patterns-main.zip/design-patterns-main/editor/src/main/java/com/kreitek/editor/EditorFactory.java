package com.kreitek.editor;

public class EditorFactory {
    public Editor getEditor(String Editor) {
        if (Editor == "json"){
            return new JsonEditor();
        }else
        return new ConsoleEditor();
    }


}
