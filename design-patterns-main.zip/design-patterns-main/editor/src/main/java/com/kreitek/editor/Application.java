package com.kreitek.editor;

public class Application {

    public static void main(String[] args) {
        EditorFactory editorFactory = new EditorFactory();
        Editor json = editorFactory.getEditor("json");
        Editor text = editorFactory.getEditor("text");

        if (args[0].equals("json")) {
            json.run(args);
        } else if (args[0].equals("text")) {
            text.run(args);
        }else{
            System.out.println("incorrect Format Text, Choose a valid one");
            text.run(args);
        }
    }

}
